//
// Copyright 2024 andiisking
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
package com.kyroos.app.ui.screens

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.widget.Toast
import android.graphics.BitmapFactory
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog

import com.kyroos.app.ui.components.*
import com.kyroos.app.ui.theme.*
import com.kyroos.app.utils.ShellUtils
import com.kyroos.app.utils.toImageBitmap

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.URL

object AppCache {
    var cachedApps by mutableStateOf<List<AppItem>>(emptyList())
    var githubAvatar by mutableStateOf<ImageBitmap?>(null)
}

data class AppItem(val name: String, val packageName: String, val icon: ImageBitmap?)

fun readKyroosConfig(dirPath: String): Map<String, String> {
    val file = File(dirPath, "kyroos.conf")
    if (!file.exists()) return emptyMap()
    return try {
        file.readLines().mapNotNull {
            val parts = it.split("=")
            if (parts.size >= 2) parts[0].trim() to parts[1].trim() else null
        }.toMap()
    } catch (e: Exception) { emptyMap() }
}

fun updateKyroosConfig(dirPath: String, key: String, value: String) {
    val file = File(dirPath, "kyroos.conf")
    try {
        if (!file.exists()) {
            file.parentFile?.mkdirs()
            file.createNewFile()
        }
        val lines = file.readLines().toMutableList()
        var found = false
        for (i in lines.indices) {
            if (lines[i].startsWith("$key=")) {
                lines[i] = "$key=$value"
                found = true
                break
            }
        }
        if (!found) lines.add("$key=$value")
        file.writeText(lines.joinToString("\n"))
    } catch (e: Exception) { e.printStackTrace() }
}

fun updateAppListInConfig(scriptDirPath: String, key: String, packageName: String, isAdded: Boolean): String {
    val conf = readKyroosConfig(scriptDirPath)
    val currentList = conf[key]?.split(",")?.map { it.trim() }?.filter { it.isNotBlank() }?.toMutableList() ?: mutableListOf()
    
    if (isAdded) {
        if (!currentList.contains(packageName)) currentList.add(packageName)
    } else {
        currentList.remove(packageName)
    }
    
    val newListString = currentList.joinToString(",")
    updateKyroosConfig(scriptDirPath, key, newListString)
    return newListString
}

@Composable
fun WavyLoadingIndicator(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "wavy_loading")
    val circleColors = listOf(MdPrimary, MdPrimary.copy(alpha = 0.8f), MdPrimary.copy(alpha = 0.5f))

    Row(
        modifier = modifier, 
        horizontalArrangement = Arrangement.spacedBy(8.dp), 
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (i in 0 until 3) {
            val yOffset by infiniteTransition.animateFloat(
                initialValue = 0f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = keyframes {
                        durationMillis = 1200
                        0f at 0
                        0f at i * 150
                        1f at (i * 150) + 300 with FastOutSlowInEasing
                        0f at (i * 150) + 600 with FastOutSlowInEasing
                        0f at 1200
                    },
                    repeatMode = RepeatMode.Restart
                ),
                label = "wave_$i"
            )

            Box(
                modifier = Modifier
                    .size(14.dp)
                    .offset(y = (-12).dp * yOffset)
                    .clip(CircleShape)
                    .background(circleColors[i])
            )
        }
    }
}

@Composable
fun HardwareRow(icon: ImageVector, title: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(modifier = Modifier.size(40.dp).clip(CircleShape).background(MdSurfaceContainerHigh), contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = null, tint = MdPrimary, modifier = Modifier.size(20.dp))
        }
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontSize = 12.sp, color = MdOutline)
            Text(value, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = MdOnBg, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun HomeScreen(isShizukuReady: Boolean, scriptDirPath: String) {
    val context = LocalContext.current
    
    var socInfo by remember { mutableStateOf("Scanning...") }
    var ramInfo by remember { mutableStateOf("Calculating...") }
    var kernelInfo by remember { mutableStateOf("Checking...") }
    var currentProfile by remember { mutableStateOf("Reading...") }
    
    val androidVersion = "Android ${Build.VERSION.RELEASE}"
    val appVersion = try { context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "1.0" } catch (e: Exception) { "1.0" }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
            val memInfo = android.app.ActivityManager.MemoryInfo()
            actManager.getMemoryInfo(memInfo)
            val resolvedRam = String.format("%.1f GB", memInfo.totalMem.toFloat() / (1024 * 1024 * 1024))

            val resolvedSoc = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                Build.SOC_MODEL.ifEmpty { Build.BOARD }
            } else {
                Build.HARDWARE.ifEmpty { Build.BOARD }
            }.uppercase()

            val resolvedKernel = System.getProperty("os.version") ?: "Unknown"

            val conf = readKyroosConfig(scriptDirPath)
            val resolvedProfile = (conf["profile"] ?: "None").replaceFirstChar { it.uppercase() }

            withContext(Dispatchers.Main) {
                socInfo = resolvedSoc
                ramInfo = resolvedRam
                kernelInfo = resolvedKernel
                currentProfile = resolvedProfile
            }
        }
    }

    val profileIcon = when (currentProfile.lowercase()) {
        "gaming" -> Icons.Rounded.Gamepad
        "powersave" -> Icons.Rounded.BatteryChargingFull
        "extreme" -> Icons.Rounded.Bolt
        "balanced" -> Icons.Rounded.Balance
        else -> Icons.Rounded.HelpOutline
    }

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 24.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        
        Card(
            modifier = Modifier.fillMaxWidth().bounceClick { },
            colors = CardDefaults.cardColors(containerColor = MdPrimaryContainer),
            shape = RoundedCornerShape(28.dp)
        ) {
            Box(modifier = Modifier.fillMaxWidth().padding(24.dp)) {
                Icon(
                    imageVector = profileIcon, 
                    contentDescription = null, 
                    tint = MdOnPrimaryContainer.copy(alpha = 0.15f), 
                    modifier = Modifier.align(Alignment.CenterEnd).size(100.dp).offset(x = 10.dp)
                )

                Column {
                    Text("Active Profile", color = MdOnPrimaryContainer.copy(alpha = 0.8f), fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(currentProfile, color = MdOnPrimaryContainer, fontSize = 32.sp, fontWeight = FontWeight.Black)
                    
                    Spacer(modifier = Modifier.height(14.dp))
                    
                    val statusBg = if (isShizukuReady) MdOnPrimaryContainer.copy(alpha = 0.2f) else Color.Black.copy(alpha = 0.2f)
                    val statusTint = if (isShizukuReady) MdOnPrimaryContainer else MdOnPrimaryContainer.copy(alpha = 0.6f)
                    val statusText = if (!isShizukuReady) "Waiting Shizuku" else if (currentProfile == "None") "System Standby" else "System Active"
                    val statusIconObj = if (!isShizukuReady) Icons.Rounded.HourglassEmpty else if (currentProfile == "None") Icons.Rounded.Bedtime else Icons.Rounded.Bolt
                    
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.clip(CircleShape).background(statusBg).padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Icon(statusIconObj, contentDescription = null, tint = statusTint, modifier = Modifier.size(18.dp))
                        Text(statusText, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = statusTint)
                    }
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MdSurfaceContainer),
            shape = RoundedCornerShape(28.dp)
        ) {
            Column(modifier = Modifier.padding(vertical = 12.dp)) {
                HardwareRow(icon = Icons.Rounded.Verified, title = "Kyroos Version", value = "v$appVersion")
                HardwareRow(icon = Icons.Rounded.Android, title = "OS Version", value = androidVersion)
                HardwareRow(icon = Icons.Rounded.DeveloperBoard, title = "SoC Platform", value = socInfo)
                HardwareRow(icon = Icons.Rounded.Storage, title = "System RAM", value = ramInfo)
                HardwareRow(icon = Icons.Rounded.Terminal, title = "Kernel Version", value = kernelInfo)
            }
        }
    }
}

@Composable
fun AppsScreen(onAppClick: (String) -> Unit) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(AppCache.cachedApps.isEmpty()) }

    LaunchedEffect(Unit) {
        if (AppCache.cachedApps.isEmpty()) {
            delay(600) 
            withContext(Dispatchers.IO) {
                val pm = context.packageManager
                val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
                val userPackages = packages.filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 || (it.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0 }
                val apps = userPackages.map { AppItem(name = pm.getApplicationLabel(it).toString(), packageName = it.packageName, icon = try { pm.getApplicationIcon(it).toImageBitmap() } catch (e: Exception) { null }) }.sortedBy { it.name.lowercase() }
                
                withContext(Dispatchers.Main) {
                    AppCache.cachedApps = apps
                    isLoading = false
                }
            }
        }
    }

    val filteredApps = AppCache.cachedApps.filter { it.name.contains(searchQuery, true) || it.packageName.contains(searchQuery, true) }

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        OutlinedTextField(value = searchQuery, onValueChange = { searchQuery = it }, modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp), placeholder = { Text("Search user apps...", color = MdOutline) }, shape = CircleShape, colors = OutlinedTextFieldDefaults.colors(focusedContainerColor = MdSurfaceContainer, unfocusedContainerColor = MdSurfaceContainer, focusedBorderColor = MdPrimary, unfocusedBorderColor = Color.Transparent, focusedTextColor = MdOnBg, unfocusedTextColor = MdOnBg), singleLine = true, leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, tint = MdPrimary) })
        
        if (isLoading) { 
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { 
                WavyLoadingIndicator() 
            } 
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filteredApps, key = { it.packageName }) { app ->
                    Card(modifier = Modifier.fillMaxWidth().bounceClick { onAppClick(app.packageName) }, colors = CardDefaults.cardColors(containerColor = MdSurfaceContainer), shape = RoundedCornerShape(20.dp)) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)).background(MdSurfaceContainerHigh), contentAlignment = Alignment.Center) { 
                                if (app.icon != null) {
                                    androidx.compose.foundation.Image(bitmap = app.icon, contentDescription = null, modifier = Modifier.fillMaxSize()) 
                                } else {
                                    Icon(Icons.Rounded.Android, contentDescription = null, tint = MdPrimary)
                                }
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Column { Text(app.name, color = MdOnBg, fontSize = 16.sp, fontWeight = FontWeight.Bold); Text(app.packageName, color = MdOutline, fontSize = 11.sp) }
                        }
                    }
                }
                item { Spacer(modifier = Modifier.height(20.dp)) }
            }
        }
    }
}

@Composable
fun ConfigMainScreen(scriptDirPath: String, onNavigate: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var profileDialog by remember { mutableStateOf(false) }
    var showDevModal by remember { mutableStateOf(false) }
    var currentProfile by remember { mutableStateOf("None") }

    LaunchedEffect(Unit) {
        delay(600)
        withContext(Dispatchers.IO) {
            val conf = readKyroosConfig(scriptDirPath)
            val prof = conf["profile"]?.replaceFirstChar { it.uppercase() } ?: "None"
            withContext(Dispatchers.Main) { currentProfile = prof }
        }
    }

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        
        ConfigCardNav("System Profile", "Current: $currentProfile", Icons.Rounded.Speed) { profileDialog = true }
        
        ConfigCardNav("Extra Tweaks", "Resolution & Hardcore ops", Icons.Rounded.Build) { onNavigate("Tweaks") }
        ConfigCardNav("Developer", "KonekoDev", Icons.Rounded.Person) { showDevModal = true }
        Spacer(modifier = Modifier.height(20.dp))
    }

    if (profileDialog) {
        ProfileSelectorDialog(currentProfile = currentProfile, onSelect = { prof -> 
            val isFirstSetup = (currentProfile == "None")
            currentProfile = prof.replaceFirstChar { it.uppercase() }
            updateKyroosConfig(scriptDirPath, "profile", prof)
            
            scope.launch(Dispatchers.IO) { 
                if (isFirstSetup) {
                    com.kyroos.app.engine.Profile.runInitialSetup(context)
                }
                com.kyroos.app.engine.Profile.applySystemProfile(context, prof)
            }
            profileDialog = false
        }, onDismiss = { profileDialog = false })
    }

    if (showDevModal) DevProfileModal(onDismiss = { showDevModal = false })
}

@Composable
fun ProfileSelectorDialog(currentProfile: String, onSelect: (String) -> Unit, onDismiss: () -> Unit) {
    val profiles = listOf(
        Triple("Balanced", "Default optimized balance", Icons.Rounded.Balance), 
        Triple("Powersave", "Prioritize battery savings", Icons.Rounded.BatteryChargingFull), 
        Triple("Gaming", "Higher clocks for gaming", Icons.Rounded.Gamepad), 
        Triple("Extreme", "Unlock maximum performance", Icons.Rounded.Bolt)
    )
    
    AlertDialog(
        onDismissRequest = onDismiss, 
        containerColor = MdSurfaceContainerHigh, 
        shape = RoundedCornerShape(32.dp), 
        title = { Text("Select Profile", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = MdPrimary) }, 
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                profiles.forEach { (name, desc, icon) ->
                    val isSelected = currentProfile.lowercase() == name.lowercase()
                    Surface(
                        modifier = Modifier.fillMaxWidth().bounceClick { onSelect(name.lowercase()) }, 
                        color = if (isSelected) MdPrimaryContainer else MdSurfaceContainer, 
                        shape = RoundedCornerShape(24.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp).fillMaxWidth(), 
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier.size(42.dp).clip(CircleShape).background(if (isSelected) MdPrimary else MdSurfaceContainerHigh),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(icon, contentDescription = null, tint = if (isSelected) MdOnPrimary else MdOutline, modifier = Modifier.size(22.dp))
                                }
                                Spacer(modifier = Modifier.width(16.dp))
                                Column { 
                                    Text(name, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = if (isSelected) MdOnPrimaryContainer else MdOnBg)
                                    Text(desc, fontSize = 12.sp, color = if (isSelected) MdOnPrimaryContainer.copy(alpha = 0.8f) else MdOutline)
                                }
                            }
                            if (isSelected) {
                                Icon(Icons.Rounded.CheckCircle, contentDescription = "Selected", tint = MdPrimary, modifier = Modifier.size(24.dp))
                            }
                        }
                    }
                }
            }
        }, 
        confirmButton = {
            TextButton(onClick = onDismiss, modifier = Modifier.padding(end = 8.dp, bottom = 8.dp)) { 
                Text("Close", fontWeight = FontWeight.Bold, color = MdOutline) 
            }
        }
    )
}

@Composable
fun TweaksScreen(scriptDirPath: String, onNavigateOpaps: () -> Unit) {
    var customRes by remember { mutableStateOf(false) }
    var resW by remember { mutableStateOf("") }
    var resH by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    var currentRenderer by remember { mutableStateOf("Checking...") }
    var showRendererDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            val prop = ShellUtils.execShizuku("getprop debug.hwui.renderer").trim()
            withContext(Dispatchers.Main) {
                currentRenderer = prop.ifEmpty { "Default" } 
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        
        ConfigCardNav("Renderer Selection", "Current: $currentRenderer", Icons.Rounded.Layers) { 
            showRendererDialog = true 
        }
        
        ExpandableConfigCard("Custom Resolution", "Modify screen size", Icons.Rounded.FitScreen, customRes, onCheckedChange = { customRes = it }) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = resW, onValueChange = { resW = it }, placeholder = { Text("W") }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp), singleLine = true)
                OutlinedTextField(value = resH, onValueChange = { resH = it }, placeholder = { Text("H") }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp), singleLine = true)
            }
            Button(onClick = { scope.launch(Dispatchers.IO) { ShellUtils.execShizuku("wm size ${resW}x${resH}") } }, modifier = Modifier.fillMaxWidth().padding(top = 12.dp), shape = RoundedCornerShape(16.dp)) { Text("Apply") }
            Button(onClick = { scope.launch(Dispatchers.IO) { ShellUtils.execShizuku("wm size reset") } }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = MdSecondaryContainer, contentColor = MdOnSecondaryContainer), shape = RoundedCornerShape(16.dp)) { Text("Reset") }
        }
        
        ConfigCardNav("Brutal AppOps", "Aggressive restriction", Icons.Rounded.GppBad) { onNavigateOpaps() }
    }

    if (showRendererDialog) {
        AlertDialog(
            onDismissRequest = { showRendererDialog = false },
            containerColor = MdSurfaceContainerHigh,
            shape = RoundedCornerShape(32.dp),
            title = { Text("Select HWUI Renderer", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = MdPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    val options = listOf(
                        Pair("skiagl", "Skia OpenGL (Stable UI & Games)"),
                        Pair("skiavk", "Skia Vulkan (Better performance/FPS on newer GPUs)"),
                        Pair("default", "Reset to System Default")
                    )
                    options.forEach { (name, desc) ->
                        val isSelected = currentRenderer.lowercase() == name.lowercase() || (currentRenderer == "Default" && name == "default")
                        Surface(
                            modifier = Modifier.fillMaxWidth().bounceClick {
                                scope.launch(Dispatchers.IO) {
                                    if (name == "default") {
                                        ShellUtils.execShizuku("setprop debug.hwui.renderer \"\"")
                                    } else {
                                        ShellUtils.execShizuku("setprop debug.hwui.renderer $name")
                                    }
                                    
                                    val newProp = ShellUtils.execShizuku("getprop debug.hwui.renderer").trim()
                                    withContext(Dispatchers.Main) {
                                        currentRenderer = newProp.ifEmpty { "Default" }
                                        showRendererDialog = false
                                    }
                                }
                            },
                            color = if (isSelected) MdPrimaryContainer else MdSurfaceContainer,
                            shape = RoundedCornerShape(24.dp)
                        ) {
                            Row(modifier = Modifier.padding(16.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(name.uppercase(), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = if (isSelected) MdOnPrimaryContainer else MdOnBg)
                                    Text(desc, fontSize = 12.sp, color = if (isSelected) MdOnPrimaryContainer.copy(alpha = 0.8f) else MdOutline)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showRendererDialog = false }) { Text("Close", color = MdOutline) }
            }
        )
    }
}

@Composable
fun AppDetailScreen(packageName: String) {
    val context = LocalContext.current
    val scriptDirPath = File(context.getExternalFilesDir(null), "scripts").absolutePath
    val scope = rememberCoroutineScope()
    
    var angleDriver by remember { mutableStateOf(false) }
    var gameDriver by remember { mutableStateOf(false) }
    var devDriver by remember { mutableStateOf(false) }
    var whitelist by remember { mutableStateOf(false) }

    LaunchedEffect(packageName) {
        withContext(Dispatchers.IO) {
            val conf = readKyroosConfig(scriptDirPath)
            val angleApps = conf["angle_apps"]?.split(",") ?: emptyList()
            val gameApps = conf["game_apps"]?.split(",") ?: emptyList()
            val devApps = conf["dev_apps"]?.split(",") ?: emptyList()
            val wlApps = conf["whitelist_apps"]?.split(",") ?: emptyList()

            withContext(Dispatchers.Main) {
                angleDriver = angleApps.contains(packageName)
                gameDriver = gameApps.contains(packageName)
                devDriver = devApps.contains(packageName)
                whitelist = wlApps.contains(packageName)
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Column(modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(modifier = Modifier.size(80.dp).clip(RoundedCornerShape(24.dp)).background(MdSurfaceContainerHigh), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.SettingsApplications, contentDescription = null, tint = MdPrimary, modifier = Modifier.size(44.dp)) }
            Spacer(modifier = Modifier.height(16.dp))
            Text(packageName, color = MdOutline, fontSize = 14.sp, modifier = Modifier.background(MdSurfaceContainerHigh, CircleShape).padding(horizontal = 12.dp, vertical = 4.dp))
        }

        ConfigCardSwitch("Angle Driver", "Force OpenGL ES (ANGLE)", Icons.Rounded.Architecture, angleDriver) { 
            angleDriver = it
            scope.launch(Dispatchers.IO) { 
                val newList = updateAppListInConfig(scriptDirPath, "angle_apps", packageName, it)
                if(newList.isNotEmpty()) {
                    ShellUtils.execShizuku("settings put global angle_gl_driver_selection_pkgs $newList")
                } else {
                    ShellUtils.execShizuku("settings delete global angle_gl_driver_selection_pkgs")
                }
            } 
        }
        
        ConfigCardSwitch("Game Driver", "Use Game Driver Overlay", Icons.Rounded.SportsEsports, gameDriver) { 
            gameDriver = it
            if(it) devDriver = false 
            scope.launch(Dispatchers.IO) { 
                val newList = updateAppListInConfig(scriptDirPath, "game_apps", packageName, it)
                if(it) updateAppListInConfig(scriptDirPath, "dev_apps", packageName, false)
                
                if(newList.isNotEmpty()) {
                    ShellUtils.execShizuku("settings put global game_driver_opt_in_apps $newList")
                } else {
                    ShellUtils.execShizuku("settings delete global game_driver_opt_in_apps")
                }
            } 
        }
        
        ConfigCardSwitch("Developer Driver", "Use Prerelease Driver", Icons.Rounded.DeveloperMode, devDriver) { 
            devDriver = it
            if(it) gameDriver = false
            scope.launch(Dispatchers.IO) { 
                val newList = updateAppListInConfig(scriptDirPath, "dev_apps", packageName, it)
                if(it) updateAppListInConfig(scriptDirPath, "game_apps", packageName, false)
                
                if(newList.isNotEmpty()) {
                    ShellUtils.execShizuku("settings put global game_driver_prerelease_opt_in_apps $newList")
                } else {
                    ShellUtils.execShizuku("settings delete global game_driver_prerelease_opt_in_apps")
                }
            } 
        }
        
        ConfigCardSwitch("Battery Whitelist", "Add to Device Idle Whitelist", Icons.Rounded.BatterySaver, whitelist) { 
            whitelist = it
            scope.launch(Dispatchers.IO) { 
                updateAppListInConfig(scriptDirPath, "whitelist_apps", packageName, it)
                ShellUtils.execShizuku(if(it) "cmd deviceidle whitelist +$packageName" else "cmd deviceidle whitelist -$packageName") 
            } 
        }
    }
}

@Composable
fun OpapsScreen(scriptDirPath: String) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    
    AppsScreen { pkg -> 
        Toast.makeText(context, "Processing Opaps: $pkg...", Toast.LENGTH_SHORT).show()
        
        scope.launch(Dispatchers.IO) { 
            val script = """
                cmd notification post -t "KyrooS" "Optimizing $pkg"
                for permission_ops in RUN_IN_BACKGROUND RUN_ANY_IN_BACKGROUND WAKE_LOCK START_FOREGROUND; do
                    appops set "$pkg" "${'$'}permission_ops" ignore 2>/dev/null
                done
                for op in ${'$'}(appops get "$pkg" | awk -F: '{print ${'$'}1}' | tr -d ' '); do
                    appops set "$pkg" "${'$'}op" ignore 2>/dev/null
                done
            """.trimIndent()
            
            ShellUtils.execShizuku(script)
            
            withContext(Dispatchers.Main) {
                Toast.makeText(context, "Applied to $pkg!", Toast.LENGTH_SHORT).show()
            }
        } 
    }
}

@Composable
fun DevProfileModal(onDismiss: () -> Unit) {
    val context = LocalContext.current
    LaunchedEffect(Unit) {
        if (AppCache.githubAvatar == null) {
            withContext(Dispatchers.IO) {
                try {
                    val bitmap = BitmapFactory.decodeStream(URL("https://github.com/andiisking.png").openConnection().getInputStream())
                    AppCache.githubAvatar = bitmap.asImageBitmap()
                } catch (e: Exception) { e.printStackTrace() }
            }
        }
    }
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(32.dp),
            colors = CardDefaults.cardColors(containerColor = MdSurfaceContainer),
            modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.fillMaxWidth().height(115.dp).background(MdPrimary))
                
                Box(Modifier.height(55.dp).fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
                    Surface(
                        shape = CircleShape, 
                        color = MdSurfaceContainer, 
                        modifier = Modifier.offset(y = (-50).dp).requiredSize(100.dp)
                    ) {
                        Box(
                            modifier = Modifier.fillMaxSize().padding(5.dp).clip(CircleShape).background(MdSurfaceContainerHigh),
                            contentAlignment = Alignment.Center
                        ) {
                            if (AppCache.githubAvatar != null) {
                                androidx.compose.foundation.Image(
                                    bitmap = AppCache.githubAvatar!!, 
                                    contentDescription = "Avatar", 
                                    modifier = Modifier.fillMaxSize().clip(CircleShape),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Icon(Icons.Rounded.Person, null, tint = MdPrimary, modifier = Modifier.size(50.dp))
                            }
                        }
                    }
                }

                Column(
                    modifier = Modifier.padding(horizontal = 24.dp).offset(y = (-25).dp), 
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "Life is a dih", 
                        fontSize = 14.sp, 
                        fontStyle = FontStyle.Italic, 
                        color = MdOnBg
                    )
                    Spacer(Modifier.height(4.dp))
                    
                    Text(
                        "KonekoDev", 
                        fontSize = 26.sp, 
                        fontWeight = FontWeight.ExtraBold, 
                        color = MdOnBg,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(6.dp))
                    
                    Surface(
                        shape = RoundedCornerShape(12.dp), 
                        color = MdPrimaryContainer.copy(alpha = 0.5f)
                    ) {
                        Text(
                            "KyrooS Developer",
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                            fontSize = 11.sp, 
                            fontWeight = FontWeight.Bold, 
                            color = MdOnPrimaryContainer
                        )
                    }
                    
                    Spacer(Modifier.height(35.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                        Surface(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/andiisking"))) }, modifier = Modifier.size(65.dp), shape = RoundedCornerShape(20.dp), color = Color(0xFF24292E)) {
                            Box(contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Code, null, tint = Color.White, modifier = Modifier.size(28.dp)) }
                        }
                        Spacer(Modifier.width(16.dp))
                        Surface(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/Koneko_dev"))) }, modifier = Modifier.size(65.dp), shape = RoundedCornerShape(20.dp), color = Color(0xFF2AABEE)) {
                            Box(contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Send, null, tint = Color.White, modifier = Modifier.size(28.dp)) }
                        }
                        Spacer(Modifier.width(16.dp))
                        Surface(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/Droid_ch"))) }, modifier = Modifier.size(65.dp), shape = RoundedCornerShape(20.dp), color = MdSurfaceContainerHigh) {
                            Box(contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Campaign, null, tint = MdPrimary, modifier = Modifier.size(28.dp)) }
                        }
                    }

                    Spacer(Modifier.height(30.dp))
                    
                    TextButton(
                        onClick = onDismiss, 
                        modifier = Modifier.fillMaxWidth()
                    ) { 
                        Text("Close", color = MdOutline, fontWeight = FontWeight.Bold) 
                    }
                }
            }
        }
    }
}
