//
// Copyright 2024 andiisking
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Shizuku API (https://github.com/RikkaApps/Shizuku-API) - Copyright Rikka Apps
// Used under Apache License 2.0
package com.kyroos.app

import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.kyroos.app.ui.components.KyroosBottomNav
import com.kyroos.app.ui.screens.*
import com.kyroos.app.ui.theme.*
import com.kyroos.app.utils.ShellUtils
import rikka.shizuku.Shizuku
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

enum class Screen { Home, Apps, ConfigMain, Tweaks, AppDetail, Opaps }

class MainActivity : ComponentActivity() {

    private val SHIZUKU_PERMISSION_CODE = 1001
    private var isShizukuReadyState = mutableStateOf(false)
    private lateinit var scriptDir: String

    private val shizukuPermissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == SHIZUKU_PERMISSION_CODE) {
            val granted = grantResult == PackageManager.PERMISSION_GRANTED
            isShizukuReadyState.value = granted
            runOnUiThread {
                if (granted) {
                    Toast.makeText(this, "Shizuku Ready", Toast.LENGTH_SHORT).show()
                    lifecycleScope.launch(Dispatchers.IO) { grantSelfWriteSecureSettings() }
                } else Toast.makeText(this, "Shizuku Denied", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        scriptDir = File(getExternalFilesDir(null), "scripts").absolutePath
        
        lifecycleScope.launch(Dispatchers.IO) {
            val dir = File(scriptDir)
            if (!dir.exists()) dir.mkdirs()
            
            setupShizuku()
        }

        setContent {
            KyroosTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    KyroosApp(scriptDir, isShizukuReadyState.value)
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener)
    }

    private fun setupShizuku() {
        try {
            Shizuku.addRequestPermissionResultListener(shizukuPermissionListener)
            if (Shizuku.pingBinder()) {
                if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                    Shizuku.requestPermission(SHIZUKU_PERMISSION_CODE)
                } else {
                    isShizukuReadyState.value = true
                    grantSelfWriteSecureSettings()
                }
            } else {
                runOnUiThread { Toast.makeText(this, "Shizuku is not running!", Toast.LENGTH_LONG).show() }
            }
        } catch (e: Exception) { e.printStackTrace() }
    }

    private fun grantSelfWriteSecureSettings() {
        try {
            ShellUtils.createShizukuProcess(arrayOf("pm", "grant", packageName, "android.permission.WRITE_SECURE_SETTINGS")).waitFor()
        } catch (e: Exception) { e.printStackTrace() }
    }
}

@Composable
fun KyroosApp(scriptDirPath: String, isShizukuReady: Boolean) {
    var currentScreen by remember { mutableStateOf(Screen.Home) }
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedAppPackage by remember { mutableStateOf("") }

    BackHandler(enabled = currentScreen !in listOf(Screen.Home, Screen.Apps, Screen.ConfigMain)) {
        currentScreen = when (currentScreen) {
            Screen.Tweaks -> Screen.ConfigMain
            Screen.AppDetail -> Screen.Apps
            Screen.Opaps -> Screen.Tweaks
            else -> Screen.Home
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                if (currentScreen !in listOf(Screen.Home, Screen.Apps, Screen.ConfigMain)) {
                    IconButton(onClick = {
                        currentScreen = when (currentScreen) {
                            Screen.Tweaks -> Screen.ConfigMain
                            Screen.AppDetail -> Screen.Apps
                            Screen.Opaps -> Screen.Tweaks
                            else -> Screen.Home
                        }
                    }) { Icon(Icons.Rounded.ArrowBack, contentDescription = "Back", tint = MdOnBg) }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = currentScreen.name.replace("Config", " Config"), fontSize = 20.sp, fontWeight = FontWeight.Medium, color = MdOnBg)
                } else {
                    Icon(Icons.Rounded.ViewInAr, contentDescription = "Logo", tint = MdPrimary, modifier = Modifier.size(34.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text("KyrooS", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = MdOnBg)
                }
            }

            Box(modifier = Modifier.fillMaxSize().padding(bottom = if (currentScreen in listOf(Screen.Home, Screen.Apps, Screen.ConfigMain)) 80.dp else 0.dp)) {
                Crossfade(
                    targetState = currentScreen,
                    animationSpec = tween(durationMillis = 250),
                    label = "screen_transition"
                ) { screen ->
                    when (screen) {
                        Screen.Home -> HomeScreen(isShizukuReady, scriptDirPath)
                        Screen.Apps -> AppsScreen { pkg -> selectedAppPackage = pkg; currentScreen = Screen.AppDetail }
                        Screen.ConfigMain -> ConfigMainScreen(scriptDirPath) { screenName -> currentScreen = Screen.valueOf(screenName) }
                        Screen.Tweaks -> TweaksScreen(scriptDirPath) { currentScreen = Screen.Opaps }
                        Screen.AppDetail -> AppDetailScreen(selectedAppPackage)
                        Screen.Opaps -> OpapsScreen(scriptDirPath)
                    }
                }
            }
        }

        if (currentScreen in listOf(Screen.Home, Screen.Apps, Screen.ConfigMain)) {
            Box(modifier = Modifier.align(Alignment.BottomCenter)) {
                KyroosBottomNav(selectedTab) { idx ->
                    selectedTab = idx
                    currentScreen = when (idx) { 0 -> Screen.Home; 1 -> Screen.Apps; 2 -> Screen.ConfigMain; else -> Screen.Home }
                }
            }
        }
    }
}
