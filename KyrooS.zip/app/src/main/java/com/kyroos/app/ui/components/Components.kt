//
// Copyright 2024 andiisking
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
package com.kyroos.app.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyroos.app.ui.theme.*

fun Modifier.bounceClick(onClick: () -> Unit): Modifier = this.composed {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val pressScale by animateFloatAsState(targetValue = if (isPressed) 0.94f else 1f, animationSpec = spring(dampingRatio = 0.6f, stiffness = 400f), label = "bounce")
    this.graphicsLayer { scaleX = pressScale; scaleY = pressScale }.clickable(interactionSource = interactionSource, indication = null, onClick = onClick)
}

@Composable
fun InfoItem(icon: ImageVector, title: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) {
        Box(modifier = Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(MdSurfaceContainerHigh), contentAlignment = Alignment.Center) { Icon(icon, contentDescription = null, tint = MdPrimary, modifier = Modifier.size(22.dp)) }
        Spacer(modifier = Modifier.width(16.dp))
        Column { Text(title, fontSize = 11.sp, color = MdOutline, letterSpacing = 0.5.sp); Text(value, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = MdOnBg) }
    }
}

@Composable
fun kyroosSwitchColors() = SwitchDefaults.colors(
    checkedThumbColor = MdOnPrimaryContainer, 
    checkedTrackColor = MdPrimary,
    uncheckedThumbColor = MdOutline, 
    uncheckedTrackColor = MdSurfaceContainerHigh, 
    uncheckedBorderColor = Color.Transparent
)

@Composable
fun ConfigCardSwitch(title: String, subtitle: String, icon: ImageVector, checked: Boolean, enabled: Boolean = true, onCheckedChange: (Boolean) -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().animateContentSize(animationSpec = spring(stiffness = Spring.StiffnessLow)), colors = CardDefaults.cardColors(containerColor = MdSurfaceContainer), shape = RoundedCornerShape(24.dp)) {
        Row(modifier = Modifier.padding(20.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = if (enabled) MdOutline else MdOutlineVariant, modifier = Modifier.size(26.dp))
                Spacer(modifier = Modifier.width(16.dp))
                Column { Text(title, fontSize = 17.sp, fontWeight = FontWeight.Medium, color = if (enabled) MdOnBg else MdOutline); Text(subtitle, fontSize = 13.sp, color = if (enabled) MdOutline else MdOutlineVariant) }
            }
            Switch(checked = checked, onCheckedChange = onCheckedChange, enabled = enabled, colors = kyroosSwitchColors())
        }
    }
}

@Composable
fun ConfigCardNav(title: String, subtitle: String, icon: ImageVector, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).bounceClick { onClick() }, colors = CardDefaults.cardColors(containerColor = MdSurfaceContainer), shape = RoundedCornerShape(24.dp)) {
        Row(modifier = Modifier.padding(20.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = MdOutline, modifier = Modifier.size(26.dp))
                Spacer(modifier = Modifier.width(16.dp))
                Column { Text(title, fontSize = 17.sp, fontWeight = FontWeight.Medium, color = MdOnBg); Text(subtitle, fontSize = 13.sp, color = MdOutline) }
            }
            Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = MdOutline)
        }
    }
}

@Composable
fun ExpandableConfigCard(title: String, subtitle: String, icon: ImageVector, isChecked: Boolean, enabled: Boolean = true, onCheckedChange: (Boolean) -> Unit, content: @Composable () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().animateContentSize(animationSpec = spring(stiffness = Spring.StiffnessLow)), colors = CardDefaults.cardColors(containerColor = MdSurfaceContainer), shape = RoundedCornerShape(24.dp)) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                    Icon(icon, contentDescription = null, tint = if (enabled) MdOutline else MdOutlineVariant, modifier = Modifier.size(26.dp))
                    Spacer(modifier = Modifier.width(16.dp))
                    Column { Text(title, fontSize = 17.sp, fontWeight = FontWeight.Medium, color = if (enabled) MdOnBg else MdOutline); Text(subtitle, fontSize = 13.sp, color = if (enabled) MdOutline else MdOutlineVariant) }
                }
                Switch(checked = isChecked, onCheckedChange = onCheckedChange, enabled = enabled, colors = kyroosSwitchColors())
            }
            AnimatedVisibility(visible = isChecked && enabled) { Column { Spacer(modifier = Modifier.height(12.dp)); content() } }
        }
    }
}

@Composable
fun KyroosBottomNav(selectedTab: Int, onTabSelected: (Int) -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp))
            .background(MdSurfaceContainerHigh),
        contentAlignment = Alignment.Center
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().height(84.dp).padding(horizontal = 24.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            NavItem(0, selectedTab, Icons.Rounded.Home, "Home", onTabSelected)
            NavItem(1, selectedTab, Icons.Rounded.Apps, "Apps", onTabSelected)
            NavItem(2, selectedTab, Icons.Rounded.Settings, "Config", onTabSelected)
        }
    }
}

@Composable
fun NavItem(index: Int, selectedIndex: Int, icon: ImageVector, label: String, onClick: (Int) -> Unit) {
    val isSelected = index == selectedIndex
    val iconScale by animateFloatAsState(if (isSelected) 1.15f else 1.0f, spring(dampingRatio=0.6f, stiffness=400f), label = "nav_scale")
    val bgAlpha by animateFloatAsState(if (isSelected) 1f else 0f, tween(200), label = "nav_bg")
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.bounceClick { onClick(index) }.padding(horizontal = 12.dp, vertical = 4.dp).graphicsLayer { scaleX = iconScale; scaleY = iconScale }) {
        Box(modifier = Modifier.width(60.dp).height(32.dp).clip(CircleShape).background(MdPrimaryContainer.copy(alpha = bgAlpha)), contentAlignment = Alignment.Center) { Icon(icon, contentDescription = label, tint = if (isSelected) MdOnPrimaryContainer else MdOutline, modifier = Modifier.size(22.dp)) }
        Text(text = label, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium, color = if (isSelected) MdPrimary else MdOutline, modifier = Modifier.padding(top = 4.dp))
    }
}
